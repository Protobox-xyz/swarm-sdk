class BatchIDRequiredException(Exception):
    pass
